# Hello World Demo
x <- "Hello World!"
print(x)

# NOTE: IDE Walkthrough

# Creating a data frame
df <- data.frame(
  Name = c("Cat", "Dog", "Cow", "Pig"), 
  HowMany = c(5, 10, 15, 20),
  IsPet = c(TRUE, TRUE, FALSE, FALSE))

# Print a data frame
print(df)

