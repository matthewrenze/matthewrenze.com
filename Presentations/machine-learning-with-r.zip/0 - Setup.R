install.packages("tree")
install.packages("caret")
install.packages("nnet")
install.packages("e1071")
install.packages("RCurl")

#import function from Github
require(RCurl)

url <- 'https://gist.githubusercontent.com/fawda123/5086859/raw/cc1544804d5027d82b70e74b83b3941cd2184354/nnet_plot_fun.r'

script <- getURL(url, ssl.verifypeer = FALSE)

eval(parse(text = script))

rm('script','url')
