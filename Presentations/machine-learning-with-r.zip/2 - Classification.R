# Set the working directory
setwd("C:/Users/Matthew/Dropbox/Presentations/Machine Learning with R/Demos")

# Load Iris data
iris <- read.csv("Iris.csv")

# Inspect the data
head(iris)

# Load color brewer library
library(RColorBrewer)

# Create a color palette
palette <- brewer.pal(3, "Set2")

# Create a scatterplot matrix colored by species
plot(
  x = iris[1:4], 
  col = palette[as.numeric(iris$Species)],
  pch = 19)

# View scatterplot of petal length vs width
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = palette[as.numeric(iris$Species)],
  pch = 19)

# Split Data into Test and Training Set

# Set seed to make randomness reproducable
set.seed(42)

# Randomly sample 100 of 150 row indexes
indexes <- sample(
    x = 1:150, 
    size = 100)

# Create training set from indexes
train <- iris[indexes, ]

# Create test set from remaining indexes
test <- iris[-indexes, ]

# Predict using Decision Tree

# Load decision tree package
library(tree)

# Train tree model
treeModel <- tree(
    formula = Species ~ .,
    data = train)

# Inspect the model
summary(treeModel)

# Plot the model
plot(treeModel)
text(treeModel)

# Create a scatterplot colored by species
plot(
    x = iris$Petal.Length, 
    y = iris$Petal.Width,
    pch = 19,
    col = palette[as.numeric(iris$Species)],
    main = "Iris Petal Length vs. Width",
    xlab = "Petal Length (cm)",
    ylab = "Petal Width (cm)")

# Plot the decision boundaries
partition.tree(
    tree = treeModel,
    label = "Species",
    add = TRUE)

# Predict with model
treePredictions <- predict(
    object = treeModel,
    newdata = test,
    type = "class")

# Summarize prediction accuracy
table(
    x = treePredictions, 
    y = test$Species)

# Load caret package
library(caret)

# Evaluate prediction results
confusionMatrix(
    data = treePredictions, 
    reference = test$Species)

# Predict with Neural Network

# Load Neural Network package
library(nnet)

# Train model
neuralModel <- nnet(
    formula = Species ~ .,
    data = train,
    size = 4,
    decay = 0.0001,
    maxit = 500)

# Inspect the model
summary(neuralModel)

# Plot the neural network
# NOTE: Requires script
plot(neuralModel)

# Predict with model
neuralPredictions <- predict(
    object = neuralModel,
    newdata = test[, 1:4],
    type = "class")

# Evaluate prediction results
confusionMatrix(
    data = neuralPredictions, 
    reference = test$Species)
