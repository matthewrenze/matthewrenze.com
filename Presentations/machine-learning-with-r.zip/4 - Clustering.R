# Predict clusters with K-Means Cluster Analysis

# Load Iris data
data(iris)

# Set seed to make randomness reproducable
set.seed(42)

# Create a scatterplot matrix colored by species
plot(
  x = iris[1:4], 
  col = palette[as.numeric(iris$Species)],
  pch = 19)

# View scatterplot of petal length vs width
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = palette[as.numeric(iris$Species)],
  pch = 19)

# Create K-means clusters
clusters <- kmeans(
  x = iris[, 1:4], 
  centers = 3, 
  nstart = 10)

# Plot each cluster as a shape
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = palette[as.numeric(iris$Species)], 
  pch = clusters$cluster)

# Plot centroid of clusters
points(
  x = clusters$centers[, "Petal.Length"], 
  y = clusters$centers[, "Petal.Width"],
  pch = 4, 
  lwd = 4, 
  col = "blue")

# View a table of the clusters
table(
  x = clusters$cluster, 
  y = iris$Species)
