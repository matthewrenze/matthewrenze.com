# Read CSV data
# Source: http://www.rossmanchance.com/iscam2/data/movies03RT.txt
data = read.csv("Movies.csv")

# Peek at data
head(data)

# Univariate statistics for qualitative variables
# (i.e. one categorical variable)
unique(data$Rating)
summary(data$Rating)

# Univariate statistics for quantitative variables
# (i.e. one numeric variable)
min(data$Box.Office)
max(data$Box.Office)
range(data$Box.Office)
diff(range(data$Box.Office))
mean(data$Box.Office)
median(data$Box.Office)
quantile(data$Box.Office)
quantile(data$Box.Office, 0.25)
IQR(data$Box.Office)
var(data$Box.Office)
sd(data$Box.Office)
summary(data$Box.Office)

# Note: Many other functions as well 
# (e.g., skewness, kurtosis, moments)

# Summarize entire table
summary(data)

# Bivariate statistics for two quantitative variables
# (i.e. two numeric variables)
cov(data$Score, data$Box.Office)
cov(data$Run.Time, data$Box.Office)

cor(data$Score, data$Box.Office)
cor(data$Run.Time, data$Box.Office)

# Bivariate statistics for both qualitative and quantitative variables
# (i.e. one categorical and one numeric variable)
tapply(data$Box.Office, data$Rating, mean)
tapply(data$Box.Office, data$Genre, mean)

# So we conclude, that (in 2003) 
# making a G-rated animated film 
# or a fantasy action/adventure movie 
# with a high critic score
# would be a much safer bet then an
# R-rated, SciFi Musical Western 
# that critics will hate


head(data[order(data$Box.Office, decreasing = TRUE), ], 5)


