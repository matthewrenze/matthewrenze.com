# Read CSV data
# Source: http://www.rossmanchance.com/iscam2/data/movies03RT.txt
data = read.csv("Movies.csv")

# Peek at data
head(data)

# Inspect number of variables (i.e. columns) 
ncol(data)

# Inspect number of observations (i.e. rows)
nrow(data)

# Inspect column names
names(data)

# Inspect individual variables (i.e. columns)
data$Rating
data$Box.Office

# Summarize all data
summary(data)

# Summarize qualitative variables (i.e. categorical)
summary(data$Rating)

# Summarize quantitative variables (i.e. numerical)
summary(data$Box.Office)


# Univariate statistics for qualitative variables
# (i.e. one categorical variable)
length(data$Rating)
unique(data$Rating)
table(data$Rating)

# Univariate statistics for quantitative variables
# (i.e. one numeric variable)
min(data$Box.Office)
max(data$Box.Office)
range(data$Box.Office)
diff(range(data$Box.Office))
mean(data$Box.Office)
median(data$Box.Office)
quantile(data$Box.Office)
quantile(data$Box.Office, 0.25)
IQR(data$Box.Office)
var(data$Box.Office)
sd(data$Box.Office)

# Note: Many other functions as well 
# (e.g., skewness, kurtosis, moments)

# Bivariate statistics for qualitative and quantitative variables
# (i.e. one categorical and one numeric variable)
tapply(data$Box.Office, data$Rating, mean)
tapply(data$Box.Office, data$Genre, mean)

# Bivariate statistics for two quantitative variables
# (i.e. two numeric variables)
cov(data$Score, data$Box.Office)
cov(data$Run.Time, data$Box.Office)

cor(data$Score, data$Box.Office)
cor(data$Run.Time, data$Box.Office)

# So we conclude, that (in 2003) making a 
# G-rated animated film 
# or a fantasy action/adventure movie 
# with a high critic score
# would be a much safer bet then an
# R-rated, SciFi Western Musical that critics hate

head(data[order(data$Box.Office, decreasing = TRUE), ], 5)


