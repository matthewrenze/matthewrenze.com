# Set working directory
setwd("C:/Users/Matthew/Desktop/Presentations/Exploratory Data Analysis with R/Data")

# Load data from CSV file
loansData = read.csv("loansData.csv")

# Peek at data
head(loansData)

# Look at column names
names(loansData)

# Problem #1: Column Name is too long
names(loansData)[2]

# Rename variables (i.e. columns)
names(loansData)[2] = "Amount.Funded"

# Problem #1 solved
names(loansData)[2]

# Problem #2: Missing values
# Find missing values
sum(is.na(loansData))

# Exclude observations with missing values
loansData = na.omit(loansData)

# Problem #2 solved
sum(is.na(loansData))

# Problem #3 Percent signs in interest rate column
# Peek at the raw interest rate data
head(loansData$Interest.Rate)

# NOTE: This next line will throw an error
mean(loansData$Interest.Rate)

# Determine the data type
class(loansData$Interest.Rate)

# Cast from factor to character string
interestRates = as.character(loansData$Interest.Rate)
head(interestRates)
class(interestRates)

# Eliminate the % character
interestRates = sub("%", "", interestRates)
head(interestRates)

# Cast the character string to numeric
loansData$Interest.Rate = as.numeric(interestRates)
head(loansData$Interest.Rate)
class(loansData$Interest.Rate)

# Now we can perform functions that expect numeric values
mean(loansData$Interest.Rate)

#Save data to a CSV file
write.csv(loansData, "loansData2.csv")

