# Set working directory
setwd("C:/Users/Matthew/Desktop/Presentations/20131102- Exploratory Data Analysis with R/Data")

# Load data from CSV file
csvData = read.csv("loansData.csv")

# Load data with specific parameters
tabData = read.table(file = "loansData.txt", header = TRUE, sep = "\t", quote="")

# Load data from R data File
load("loansData.rda")

# Peek at data
head(loansData)

# Look at column names
names(loansData)

# Rename variables (i.e. columns)
names(loansData)[2] = "Amount.Funded"

# Finding duplicate variable names
anyDuplicated(names(loansData))

# Find missing values
sum(is.na(loansData))

# Exclude observations with missing values
loansData = na.omit(loansData)


# We need to transform raw interest rate values
# into numeric values
# NOTE: This next line will throw an error
mean(loansData$Interest.Rate)

# Peek at the raw interest rate data
head(loansData$Interest.Rate)

# Determine the data type
class(loansData$Interest.Rate)

# Cast from factor to character string
interestRates = as.character(loansData$Interest.Rate)
head(interestRates)

# Eliminate the % character
interestRates = sub("%", "", interestRates)
head(interestRates)

# Cast the character string to numeric
loansData$Interest.Rate = as.numeric(interestRates)
head(loansData$Interest.Rate)
class(loansData$Interest.Rate)

# Now we can perform functions that expect numeric values
mean(loansData$Interest.Rate)

#Save data to a CSV file
write.csv(loansData, "loansData2.csv")
