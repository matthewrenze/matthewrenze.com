# Read CSV data
# Source: http://www.rossmanchance.com/iscam2/data/movies03RT.txt
data = read.csv("Movies.csv")

# Draw scatterplot of box office revenue and critic score
plot(data$Score, data$Box.Office)

# Create a linear regression model
model = lm(data$Box.Office ~ data$Score)

# Draw linear regression model on plot
lines(data$Score, model$fitted, col = "red", lwd = 3)

# Summarize the model
summary(model)

# Get confidence intervals for the model
confint(model)

# Visualize the residuals
plot(data$Box.Office, model$residual)
