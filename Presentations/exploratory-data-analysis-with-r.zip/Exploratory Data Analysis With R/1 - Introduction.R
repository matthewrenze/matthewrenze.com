# NOTE: Walkthrough of IDE

# Assignment operators
x = "Hello World!"
y <- "Hello World!"
"Hello World!" -> z

# Implicit printing
x

# Creating variables
b = TRUE
i = 123L
n = 123.45
c = "ABC 123"

# Displaying variables
b
i
n
c

# Creating a function
f = function(x) { x + 1 }

# Invoke a function
f(2)

#Data Structures
# Create a vector of numerics
v = c(1, 2, 3);
v

# Create a vector from an integer sequence
s = 1:5
s

# Create a matrix
m = matrix(data = 1:6, nrow = 2, ncol = 3)
m

# Create a array
a = array(data = 1:8, dim = c(2, 2, 2))
a

# Create a list of heterogeneous data types
l = list(TRUE, 1, 2.34, "abc")
l

# Create a set of factors
factors = factor(c("Male", "Female", "Male", "Male", "Female"))
levels(factors)
unclass(factors)

# Create a data frame
df = data.frame(
  Name = c("Cat", "Dog", "Cow", "Pig"), 
  HowMany = c(5, 10, 15, 20),
  IsPet = c(TRUE, TRUE, FALSE, FALSE))
df

# Indexing data frames by row and column
df[1, 2]

# Indexing data frames by row
df[1, ]

# Indexing data frames by column
df[ , 2]
df[["HowMany"]]
df$HowMany

# Subsetting data frames
df[c(2, 4), ]
df[2:4, ]
df[c(TRUE, FALSE, TRUE, FALSE), ]
df[df$IsPet == TRUE, ]
df[df$HowMany > 10, ]
df[df$Name %in% c("Cat", "Cow"), ]

# Note: Indexing and subsetting applies to: 
# vectors, lists, matrices, and arrays 

# R is a vectorized language
# All atomic data types are vectors of size 1
# Most operations are vectorized
1 + 2
c(1, 2, 3) + c(2, 4, 6)

# Named parameters vs. ordered parameters
m = matrix(data = 1:6, nrow = 2, ncol = 3)
n = matrix(1:6, 2, 3) 
m == n
identical(m, n)

# Installing packages (command line)
install.packages("ggplot2")

# Loading libraries
library(ggplot2)

# View help
?nrow

# NOTE: R also contains most basic languages features
# you expect in C-like languages 
# e.g. if-then-else, for-loops, while-loops, switches, etc. 

