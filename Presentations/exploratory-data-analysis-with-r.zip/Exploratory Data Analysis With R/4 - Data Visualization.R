# Read CSV data
# Source: http://www.rossmanchance.com/iscam2/data/movies03RT.txt
data = read.csv("Movies.csv")


# Univariate visualizations for qualitiative variables
# (i.e. one categorical variable)

# Create bar graph of counts for qualitative  (e.g. categorical) variables
plot(data$Rating)
plot(data$Genre, las = 2)

# Pie charts (not recommended)
ratings = table(data$Rating)
pie(ratings)


# Univariate visualizations of quantitiative variables
# (i.e. one numeric variable)

# Draw dot plot of Score
plot(x = data$Score, y = rep(0, nrow(data)), ylab = "", yaxt = "n")

# Create boxplots of Score
boxplot(data$Score, xlab = "Score", horizontal = TRUE)

# Create histogram of Score
hist(data$Score)
points(data$Score, data$Score * 0)

# Plot density of Score
plot(density(data$Score))
points(data$Score, data$Score * 0)

# Repeat for Box Office Score
plot(x = data$Box.Office, y = rep(0, nrow(data)), ylab = "", yaxt = "n")

boxplot(data$Box.Office, xlab = "Box Office", horizontal = TRUE)

hist(data$Box.Office)
points(data$Box.Office, data$Box.Office * 0)

plot(density(data$Box.Office))
points(data$Box.Office, data$Box.Office * 0)


# Bivariate visualizations for qualitiative variables
# (i.e. two categorical variables)

# Plot a bivariate stacked bar chart for Genre
plot(data$Genre, data$Rating, las = 3)


# Bivariate visualizations for qualitiative and quantitiative variables
# (i.e. one categorical and one numerical variable)

# Plot bivariate box plots
plot(data$Rating, data$Box.Office, ylab = "Box Office ($)")
plot(data$Genre, data$Box.Office, ylab = "Box Office ($)", las = 2)


# Bivariate visualizations for two quantitiative variables
# (i.e. two numerical variables)

# Plot scatterplots
plot(data$Score, data$Box.Office)
plot(data$Run.Time, data$Box.Office)

# 3-Variable visualizations
# (i.e. two numerical and one categorical variables)

# Color scatterplot by Rating
plot(data$Score, data$Box.Office)
plot(data$Score, data$Box.Office, col=data$Rating, pch=19)
legend("bottomright", as.character(levels(data$Rating)), col=1:4, pch=19, cex=1)

# Shape scatterplot by Rating
plot(data$Score, data$Box.Office, pch=as.integer(data$Rating))
legend("bottomright", as.character(levels(data$Rating)), pch=1:4, cex=1)

# 3-Variable quantitative visualizations
# (i.e. three numerical variables)

# Color scatterplot by Run Time
plot(data$Score, data$Box.Office, pch=19)
palette(heat.colors(5))
plot(data$Score, data$Box.Office, col=cut(data$Run.Time, 5), pch=19)
legend("bottomright", as.character(levels(cut(data$Run.Time, 5))), col=1:5, pch=19, cex=1)

#NOTE: In general, I wouldn't recommend trying
# to visualize more than three variables at once

# All combinations of variables simultaneously
# Scatter plot matrix
plot(data)
