# Load Iris data
data(iris)
data = iris

# Peek at data
head(data)

# Look at unique species
unique(data$Species)

# Plot scatterplot matrix
palette("default")
plot(data[1:4], col=as.integer(data$Species))

# Create K-means clusters
kClusters = kmeans(data[, 1:4], centers=3, nstart=10)

# View scatterplot of clusters
plot(data$Petal.Length, data$Petal.Width)

# Color scatterplot by species
plot(data$Petal.Length, data$Petal.Width, col = as.numeric(data$Species))

# Set shape to cluster
plot(data$Petal.Length, data$Petal.Width, col = as.numeric(data$Species), pch = kClusters$cluster)

# Draw center of clusters
points(kClusters$centers[, "Petal.Length"], kClusters$centers[, "Petal.Width"], pch = 3, lwd = 4, col = "blue")

# View a table of the clusters
table(kClusters$cluster, data$Species)
