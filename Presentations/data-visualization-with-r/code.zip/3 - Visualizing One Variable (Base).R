# Set working directory
setwd("C:/Users/Matthew/Dropbox/Presentations/Data Visualization with R/Data")

# Load movie data from CSV file
movies <- read.csv("Movies.csv")

# Peek at the data
head(movies)

# Visualizing One Categorical Variable

# Create a frequency bar chart of ratings
plot(
    x = movies$Rating,
    main = "Count of Movies by Rating",
    xlab = "Rating",
    ylab = "Count of Movies")

# Create a pie chart of ratings
pie(
    x = table(movies$Rating),
    main = "Count of Movies by Rating")

# Create a pie chart of awards
pie(
    x = table(movies$Awards),
    clockwise = TRUE,
    main = "Proportion of Movies that Won Awards")

# Visualizing One Numeric Variable

# Create a dot plot of runtime
plot(
    x = movies$Runtime, 
    y = rep(0, nrow(movies)),
    main = "Distribution of Movie Runtimes",
    xlab = "Runtime (minutes)",
    ylab = "", 
    yaxt = "n")

# Create a boxplot of runtime
boxplot(
    x = movies$Runtime, 
    horizontal = TRUE,
    main = "Distribution of Movie Runtimes",
    xlab = "Runtime (minutes)")

# Create a histogram of runtime
hist(
    x = movies$Runtime,
    main = "Distribution of Movie Runtimes",
    xlab = "Runtime (minutes)")

# Create a density plot of runtime
plot(
    x = density(movies$Runtime),
    main = "Distribution of Movie Runtimes",
    xlab = "Runtime (minutes)")
