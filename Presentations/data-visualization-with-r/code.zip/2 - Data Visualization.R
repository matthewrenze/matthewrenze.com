# Create a data frame
df <- data.frame(
    Name = c("a", "b", "c"),
    Value = c(1, 2, 3))

# Print data frame
print(df)

# Create bar plot with base plotting system
barplot(
    names = df$Name,
    height = df$Value,
    col = "#b3cde3",
    main = "Hello World",
    xlab = "Name",
    ylab = "Value")

# Download and install Lattice
install.packages("lattice")

# Load the Lattice package
library(lattice)

# Create a bar chart in Lattice
barchart(
    x = Value ~ Name,
    data = df,
    ylim = c(0, 3.1),
    col = "#b3cde3",
    main = "Hello World",
    xlab = "Name",
    ylab = "Value")

# Download and install ggplot2
install.packages("ggplot2")

# Load the ggplot2 package
library(ggplot2)

# Create a bar chart in ggplot2
ggplot(
    data = df,
    aes(
        x = Name, 
        y = Value)) +
    geom_bar(
        stat = "identity",
        fill = "#b3cde3") +
    ggtitle("Hello World") +
    xlab("Name") +
    ylab("Value")
