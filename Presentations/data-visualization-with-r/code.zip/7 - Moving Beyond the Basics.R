# Creating Animated Data Visualizations

# Load animation package
library(animation)

# Load studios data
studios <- read.csv("Studios.csv")

# Display studios data
head(studios)

# Create animation function
animate <- function() {
    for(i in 1:183)
    {
        # Get current time period data
        period <- studios[studios$Period == i,]
        
        # Create scatterplot for the time period
        plot(
            x = period$Count,
            y = period$Box.Office,
            xlim = c(0, 225),
            ylim = c(0, 17500),
            col = as.integer(period$Studio),
            pch = 19,
            cex = 2,
            main = "Top 10 Studios (2000-2015)",
            sub = period$Release,
            xlab = "Movies Released",
            ylab = "Box Office Revenue ($M)")
        
        # Display legend
        legend(
            x = "bottomright", 
            as.character(levels(studios$Studio)), 
            col = 1:10, 
            pch = 19, 
            cex = 0.75)
    }
}

# Set the frame rate
ani.options(
    interval = 0.05,
    ani.width = 640,
    ani.height = 480)

# Save the animation as a video
# NOTE: Requires ffmpeg
saveVideo(
    expr = animate(),
    video.name = "Studios.mp4",
    ffmpeg = "C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe")

# Creating Interactive Data Visualizations

# Load shiny
library(shiny)

# Create a UI
ui <- fluidPage("Hello World!")

# Create a server
server <- function(input, output) {}

# Create a shiny app
shinyApp(
    ui = ui,
    server = server)

# Create a UI with I/O controls
ui <- fluidPage(
    titlePanel("Input and Output"),
    sidebarLayout(
        sidebarPanel(
            sliderInput(
                inputId = "num",
                label = "Choose a Number",
                min = 0,
                max = 100,
                value = 25)),
        mainPanel(
            textOutput(
                outputId = "text"))))

# Create a server than maps input to output
server <- function(input, output) {
    output$text <- renderText({
        paste("You selected ", input$num )})
}

# Create a shiny app
shinyApp(
    ui = ui,
    server = server)

# Creating Interactive Data Visualizations

# Create user interface code
ui <- fluidPage(
    titlePanel("Interactive Movie Data"),
    sidebarLayout(
        sidebarPanel(
            sliderInput(
                inputId = "year",
                label = "Year",
                min = 2000,
                max = 2015,
                value = c(2000, 2016),
                sep = ""),
            checkboxGroupInput(
                inputId = "rating",
                label = "Rating",
                choices = c("G", "PG", "PG-13", "R"),
                selected = c("G", "PG", "PG-13", "R")),
            textInput(
                inputId = "title",
                label = "Title")),
        mainPanel(
            plotOutput(
                outputId = "plot"))))

# Create server code
server <- function(input, output) {
    output$plot <- renderPlot({
        subset <- movies %>%
            filter(Year >= input$year[1] ) %>%
            filter(Year <= input$year[2]) %>%
            filter(Rating %in% input$rating) %>%
            filter(grepl(input$title, Title)) %>%
            as.data.frame()
        plot(
            x = subset$Critic.Score, 
            y = subset$Box.Office, 
            col = subset$Rating, 
            pch = 19,
            xlim = c(0, 100),
            ylim = c(0, 800),
            xlab = "Critic Score (%)",
            ylab = "Box Office Revenue ($M)")
        legend(
            x = "topleft", 
            as.character(levels(movies$Rating)), 
            col = 1:4, 
            pch = 19, 
            cex = 1)})
}

shinyApp(
    ui = ui,
    server = server)
