# Visualizing Spatial Data

# Load maps package
library(maps)

# Load spatial data
spatial <- read.csv("Spatial Data.csv")

# Display spatial data
head(spatial)

# Create a bubble map (ggplot2)
ggplot() +
    borders(
        database = "world",
        colour = "grey50",
        fill = "grey80") +
    geom_point(
        aes(
            x = spatial$Lon,
            y = spatial$Lat,
            size = spatial$Size), 
        color = "red")

# Visualizing Hierachical Data

# Load treemap package
library(treemap)

# Load movies by country hierarchy
hierarchy <- read.csv("Hierarchy.csv")

# Create a treemap of box office by continent/country
treemap(
    dtf = hierarchy,
    index = c("Continent", "Code"),
    vSize = "Box.Office",
    vColor = "Box.Office",
    type = "value",
    title = "Box Office Revenue by Continent/Country")

# Visualizing Graph/Network Data

# Load iGraph package
library(igraph)

# Load graph data
actors <- read.csv("Actors.csv")

# Display twice or more acting pairs
head(actors)

# Create a undirected graph object
graph <- graph.data.frame(
    d = actors, 
    directed = FALSE)

# Plot the graph
plot(
    x = graph,
    vertex.size = 3,
    vertex.color = "SkyBlue",
    vertex.label = NA, 
    edge.curved = FALSE,
    edge.width = actors$Count,
    main = "Twice or More Acting Pairs")

# Visualize Textual Data

# Load packages
library(wordcloud)

# Load words CSV file
words <- read.csv("Words.csv")

# Peek at plot keywords
head(words, 10)

# Create word cloud sized by frequency 
# and colored by box office revenue
wordcloud(
    words = words$Word,
    freq = words$Box.Office,
    max.words = 25,
    scale = c(2, 0.5),
    colors = brewer.pal(9,"Reds"))
