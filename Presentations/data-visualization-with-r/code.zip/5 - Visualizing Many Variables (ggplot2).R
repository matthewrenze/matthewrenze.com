# Visualizing Three Categorical Variables

# Create a 2D faceted frequency bar chart
ggplot(
    data = movies, 
    aes(
        x = Rating)) +
    geom_bar() +
    facet_grid(
        facets = Awards ~ Distribution) + 
    ggtitle("Count of Movies by Rating, Awards, and Distribution") +
    xlab("Rating") +
    ylab("Count of Movies")

# Visualizing Two Categorical 
# and One Numeric Variable

# Create faceted bar chart
ggplot(
    data = movies, 
    aes(
        x = Rating, 
        y = Box.Office)) +
    geom_bar(
        stat = "summary", 
        fun.y = "mean") +
    facet_wrap(
        facets = ~Awards) +
    ggtitle("Average Box Office Revenue by Rating and Award Status") +
    xlab("Rating") +
    ylab("Box Office Revenue ($M)")

# Visualizing One Categorical
# and Two Numeric Variables

# Subset 2014 movies
movies2014 = movies[movies$Year == 2014, ]

# Create a faceted scatterplot
ggplot(
    data = movies2014,
    aes(
        x = Critic.Score, 
        y = Box.Office)) +
    geom_point() + 
    facet_wrap(
        facets = ~Rating) +
    ggtitle("Critic Score vs. Box Office Revenue by Award Status") +
    xlab("Critic Score (%)") +
    ylab("Box Office Revenue ($M)")

# Visualizing One Categorical
# Variable and a Time Series

# Load row-wise time series
timeSeries2 <- read.csv("Time Series 2.csv")

# Display time series
head(timeSeries2)

# Create a faceted line chart
ggplot(
    data = timeSeries2, 
    aes(
        x = Year, 
        y = Box.Office)) +
    geom_line() +
    facet_wrap(
        facets = ~Rating) +
    ggtitle("Box Office Revenue over Time by Rating Category") +
    xlab("Year") +
    ylab("Box Office Revenue ($M)")

# Visualizing Three Numeric Variables

# Create a bubble chart
ggplot(
    data =  movies2014,
    aes(
        x = Runtime, 
        y = Critic.Score,
        size = Box.Office, 10)) +
    geom_point() +
    scale_size_area() +
    ggtitle("Runtime, Critic Score, and Box Office Revenue") +
    xlab("Runtime (min)") +
    ylab("Critic Score (%)") +
    labs(size = "Box Office\nRevenue ($M)")

# Create 3D scatterplot (Lattice)
cloud(
    x = Box.Office ~ Critic.Score * Runtime,
    data = movies2014,
    type = c("p", "h"),
    pch = 16,
    main = "Runtime, Critic Score, and Box Office Revenue",
    xlab = "Runtime (min)",
    ylab = "Critic Score (%)",
    zlab = "Box Office\nRevenue\n($M)")

# Visualizing Many Variables

# Create a scatterplot matrix (Base)
plot(movies[ ,2:6])

# Create a scatterplot matrix (Lattice)
splom(movies[, c(2:6)])

# Create a scatterplot matrix (ggplot2)
library(GGally)

ggpairs(
    data = movies, 
    columns = c(2:6))
