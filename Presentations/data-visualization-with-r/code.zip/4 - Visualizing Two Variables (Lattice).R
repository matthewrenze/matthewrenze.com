# Visualizing Two Categorical Variables

# Create a contigency table for awards by rating
awards <- table(
    x = movies$Rating,
    y = movies$Award)

# Rename columns
colnames(awards) <- c("No", "Yes")

# Display table
print(awards)

# Create a grouped frequency bar chart
barchart(
    x = awards,
    stack = FALSE,
    horizontal = FALSE,
    main = "Count of Movies by Rating and Awards",
    xlab = "Rating",
    ylab = "Count of Movies",
    auto.key = list(
        x = 0.05,
        y = 0.95,
        title = "Awards",
        text = c("No", "Yes")))

# Create a stacked frequency bar chart
barchart(
    x = awards,
    stack = TRUE,
    horizontal = FALSE,
    main = "Count of Movies by Rating and Award",
    xlab = "Rating",
    ylab = "Count of Movies",
    auto.key = list(
        x = 0.05,
        y = 0.95,
        title = "Awards",
        text = c("No", "Yes")))

# Create a proportional frequency table
matrix <- apply(awards, 1, function(x) {x / sum(x) })

proportions <- t(matrix) # transpose matrix

# Compare old and new frequency tables
print(awards)

print(proportions)

# Create a 100% stacked frequency bar chart
barchart(
    x = proportions,
    stack = TRUE,
    horizontal = FALSE,
    main = "Proportion of Movies by Rating and Award",
    xlab = "Rating",
    ylab = "Proportion of Movies",
    auto.key = list(
        x = 0.70,
        y = 1.05,
        title = "Awards",
        columns = 2,
        text = c("No", "Yes"),
        background = "white"))

# NOTE: No spine plot or mosaic plot in lattice

# Create a spineplot (Base)
spineplot(
    x = awards,
    main = "Proportion of Movies by Rating and Awards",
    xlab = "Rating",
    ylab = "Awards")

# Create a mosaic plot (Base)
mosaicplot(
    x = awards,
    main = "Proportion of Movies by Rating and Awards",
    xlab = "Rating",
    ylab = "Awards")

# Visualizing Two Numeric Variables

# Create a scatterplot
xyplot(
    x = Box.Office ~ Runtime,
    data = movies,
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)")

# Add a linear regression line
xyplot(
    x = Box.Office ~ Runtime,
    data = movies,
    type = c("p", "r"),
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)")

# Load hexbin library
library(hexbin)

# Create hexagonal binned frequency heatmap
hexbinplot(
    x =  Box.Office ~ Runtime,
    data = movies,
    xbins = 30,
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)")

# Create a 2D kernel density estimation
library(MASS)

density2d <- kde2d(
    x = movies$Runtime, 
    y = movies$Box.Office, 
    n = 50)

# Create a grid from our 2D kernel density estimate
grid <- expand.grid(
    x = density2d$x,
    y = density2d$y)

grid$z <- as.vector(density2d$z)

# Display the data frame
head(grid)

# Create a contour plot of density
contourplot(
    x = z ~ x * y,
    data = grid,
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)")

# Create a level plot of density
levelplot(
    x = z ~ x * y,
    data = grid,
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)")

# Create mesh plot of density
wireframe(
    x = z ~ x * y,
    data = grid,
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)",
    zlab = "Density")

# Create surface plot of density
wireframe(
    x = z ~ x * y,
    data = grid,
    drape = TRUE,
    main = "Runtime vs. Box Office Revenue",
    xlab = "Runtime (minutes)",
    ylab = "Box Office ($M)",
    zlab = "Density")

# Visualizing Time Series Data

# Load time series data
timeSeries <- read.csv("Time Series.csv")

# Display the time series data
head(timeSeries)

# Create a step chart
xyplot(
    x = Box.Office ~ Year,
    data = timeSeries,
    type = "s",
    ylim = c(0, max(timeSeries$Box.Office)),
    main = "Average Box Office Revenue by Year",
    xlab = "Year",
    ylab = "Box Office ($M)")

# Create a line chart
xyplot(
    x = Box.Office ~ Year,
    data = timeSeries,
    type = "l",
    ylim = c(0, max(timeSeries$Box.Office)),
    main = "Average Box Office Revenue by Year",
    xlab = "Year",
    ylab = "Box Office ($M)")

# NOTE: Area chart possible with Lattice Extra package

# Visualizing a Numeric Variable 
# Grouped by a Categorical Variable

# Load dplyr package
library(dplyr)

# Create table of average box office by rating
average <- movies %>%
    select(Rating, Box.Office) %>%
    group_by(Rating) %>% 
    summarize(Box.Office = mean(Box.Office)) %>%
    as.data.frame()

# Display aggregate table
print(average)

# Create a bivariate bar chart
barchart(
    x = Box.Office ~ Rating,
    data = average,
    main = "Average Box Office Revenue by Rating",
    xlab = "Rating",
    ylab = "Box Office ($M)")

# Create a bivariate box plot
bwplot(
    x = Box.Office ~ Rating,
    data = movies,
    main = "Box Office Revenue by Rating",
    xlab = "Rating",
    ylab = "Box Office ($M)")

# Create a notched box plot
bwplot(
    x = Box.Office ~ Rating,
    data = movies,
    notch = TRUE,
    main = "Box Office Revenue by Rating",
    xlab = "Rating",
    ylab = "Box Office ($M)")

# Create a violin plot
bwplot(
    x = Box.Office ~ Rating,
    data = movies,
    panel = panel.violin,
    main = "Box Office Revenue by Rating",
    xlab = "Rating",
    ylab = "Box Office ($M)")
