# Install shiny package
install.packages("shiny")

# Load shiny
library(shiny)

# Create a UI
ui <- fluidPage("Hello World!")

# Create a server
server <- function(input, output) {}

# Create a shiny app
shinyApp(
    ui = ui,
    server = server)

# Create a UI with I/O controls
ui <- fluidPage(
    titlePanel("Input and Output"),
    sidebarLayout(
        sidebarPanel(
            sliderInput(
                inputId = "num",
                label = "Choose a Number",
                min = 0,
                max = 100,
                value = 25)),
        mainPanel(
            textOutput(
                outputId = "text"))))

# Create a server than maps input to output
server <- function(input, output) {
    output$text <- renderText({
        paste("You selected ", input$num )})
}

# Create a shiny app
shinyApp(
    ui = ui,
    server = server)

# Create interactive data visualization

# Load dplyr package
library(dplyr)

# Set working directory
setwd("C:/Workshop/Data")

# Load Data
movies <- read.csv("Movies.csv")

# Create user interface code
ui <- fluidPage(
    titlePanel("Interactive Movie Data"),
    sidebarLayout(
        sidebarPanel(
            sliderInput(
                inputId = "year",
                label = "Year",
                min = 2000,
                max = 2015,
                value = c(2000, 2015),
                sep = ""),
            checkboxGroupInput(
                inputId = "rating",
                label = "Rating",
                choices = c("G", "PG", "PG-13", "R"),
                selected = c("G", "PG", "PG-13", "R")),
            textInput(
                inputId = "title",
                label = "Title")),
        mainPanel(
            plotOutput(
                outputId = "plot"))))

# Create server code
server <- function(input, output) {
    output$plot <- renderPlot({
        subset <- movies %>%
            filter(Year >= input$year[1] ) %>%
            filter(Year <= input$year[2]) %>%
            filter(Rating %in% input$rating) %>%
            filter(grepl(input$title, Title)) %>%
            as.data.frame()
        plot(
            x = subset$Critic.Score, 
            y = subset$Box.Office, 
            col = subset$Rating, 
            pch = 19,
            xlim = c(0, 100),
            ylim = c(0, 800),
            xlab = "Critic Score (%)",
            ylab = "Box Office Revenue ($M)")
        legend(
            x = "topleft", 
            as.character(levels(movies$Rating)), 
            col = 1:4, 
            pch = 19, 
            cex = 1)})
}

shinyApp(
    ui = ui,
    server = server)
