# Visualizing One Categorical Variable

# Create a frequency bar chart of rating observations
plot(
    x = movies$Rating,
    main = "Frequency of Movies by Rating",
    xlab = "Rating",
    ylab = "Count of Movies")

# Create a pie chart of rating observations
pie(table(movies$Rating))

# Visualizing One Numeric Variable

# Create a dot plot of runtime
plot(
  x = movies$Runtime, 
  y = rep(0, nrow(movies)), 
  main = "Distribution of Movie Runtime",
  xlab = "Runtime (min)",
  ylab = "", 
  yaxt = "n")

# Create a boxplot of runtime
boxplot(
  x = movies$Runtime, 
  main = "Distribution of Movie Runtime",
  xlab = "Runtime (min)",
  horizontal = TRUE)

# Create a histogram of runtime
hist(
    x = movies$Runtime,
    main = "Distribution of Movie Runtime",
    xlab = "Runtime (min)",
    ylab = "Frequency")

# Create a density plot of runtime
plot(
    x = density(movies$Runtime),
    main = "Distribution of Movie Runtime",
    xlab = "Runtime (min)",
    ylab = "Density")

# Add dot plot to base of density plot
points(
  x = movies$Runtime, 
  y = rep(-0.0005, nrow(movies)))

# Visualizing Two Categorical Variables

# Create a spineplot of genre and rating
spineplot(
  x = genres$Genre, 
  y = genres$Rating,
  main = "Frequency of Movies by Rating and Genre",
  xlab = "Genre",
  ylab = "Rating")

# Create a mosaic plot of genre and rating
mosaicplot(
  x = table(
    genres$Genre, 
    genres$Rating),
  las = 3,
  main = "Frequency of Movies by Rating and Genre",
  xlab = "Genre",
  ylab = "Rating")

# Visualizing Two Numeric Variables

# Create a scatterplot of runtime and box office
plot(
  x = movies$Runtime, 
  y = movies$Box.Office,
  main = "Movie Runtime and Box Office Revenue",
  xlab = "Runtime (min)",
  ylab = "Box Office ($M)")

# Create a scatterplot of critic score and box office
plot(
  x = movies$Critic.Score, 
  y = movies$Box.Office,
  main = "Critic Score and Box Office Revenue",
  xlab = "Critic Score (%)",
  ylab = "Box Office ($M)")

# Visualize a Time Series

# Plot a line graph of average box office revenue by year
timeSeries <- tapply(movies$Box.Office, movies$Year, mean)

plot(
  x = names(timeSeries),
  y = timeSeries,
  type = "l",
  main = "Average Box Office Revenue by Year",
  xlab = "Year",
  ylab = "Average Box Office ($M)")

# Visualizing a Numeric Variable 
# Grouped By a Categorical Variable

# Create a bar graph of average box office by rating
barplot(
    height = tapply(movies$Box.Office, movies$Rating, mean),
    main = "Average Box Office Revenue by Rating Category",
    xlab = "Rating",
    ylab = "Box Office ($M)")

# Create a bar graph of average box office by genre
barplot(
  height = tapply(genres$Box.Office, genres$Genre, mean),
  las = 3,
  main = "Average Box Office Revenue by Genre",
  ylab = "Box Office ($M)")

# Visualizing Many Variables

# Create a scatterplot matrix
plot(movies)

# Load corrgram package
library(corrgram)

# Create a correlation matrix (correlogram)
corrgram(movies)
