# Load Iris data
data(iris)

# Predict with K-Means Cluster Analysis

# Create a scatterplot matrix colored by species
plot(
  x = iris[1:4], 
  col = as.integer(iris$Species))

# View scatterplot of petal length vs width
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width)

# Color scatterplot by species
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = as.numeric(iris$Species))

# Create K-means clusters
clusters <- kmeans(
  x = iris[, 1:4], 
  centers = 3, 
  nstart = 10)

# Plot each cluster as a shape
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = as.numeric(iris$Species), 
  pch = clusters$cluster)

# Plot centroid of clusters
points(
  x = clusters$centers[, "Petal.Length"], 
  y = clusters$centers[, "Petal.Width"],
  pch = 4, 
  lwd = 4, 
  col = "blue")

# View a table of the clusters
table(
  x = clusters$cluster, 
  y = iris$Species)

# Split Data into Test and Training Set

# Set seed to make randomness reproducable
set.seed(123)

# Randomly sample 100 of 150 row indexes
indexes <- sample(
    x = 1:150, 
    size = 100)

# Create training set from indexes
train <- iris[indexes, ]

# Create test set from remaining indexes
test <- iris[-indexes, ]

# Predict using Decision Tree

# Load decision tree package
library(tree)

# Train tree model
treeModel <- tree(
    formula = Species ~ .,
    data = train)

# Inspect the model
summary(treeModel)

# Plot the model
plot(treeModel)
text(treeModel)

# Predict with model
treePredictions <- predict(
    object = treeModel,
    newdata = test,
    type = "class")

# Summarize prediction accuracy
table(
    x = treePredictions, 
    y = test$Species)

# Load caret package
library(caret)

# Evaluate prediction results
confusionMatrix(
    data = treePredictions, 
    reference = test$Species)

# Predict using Naive Bayes Classifier

# Load e1071 package
library(e1071)

# Train model
bayesModel <- naiveBayes(
    formula = Species ~ ., 
    data = train)

# Inspect the model
summary(bayesModel)

# Predict with model
bayesPredictions <- predict(
    object = bayesModel, 
    newdata = test[, 1:4])

# Evaluate prediction results
confusionMatrix(
    data = bayesPredictions, 
    reference = test$Species)

# Predict with Neural Network

# Load Neural Network package
library(nnet)

# Train model
neuralModel <- nnet(
    formula = Species ~ .,
    data = train,
    size = 4,
    decay = 0.0001,
    maxit = 500)

# Inspect the model
summary(neuralModel)

# Predict with model
neuralPredictions <- predict(
    object = neuralModel,
    newdata = test[, 1:4],
    type = "class")

# Evaluate prediction results
confusionMatrix(
    data = neuralPredictions, 
    reference = test$Species)
