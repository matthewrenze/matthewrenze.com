# Load CSV data
movies <- read.csv("Movies.csv")

genres <- read.csv("Genres.csv")

# Peek at data
head(movies)

head(genres)

# Qualitative Univariate Statistics
# (i.e. one categorical variable)
table(movies$Rating)

# Quantitative Univariate Statistics
# (i.e. one numeric variable)

# Analyze central tendancy (location)
mean(movies$Runtime)

median(movies$Runtime)

# Analyze the dispersion (spread)
min(movies$Runtime)

max(movies$Runtime)

range(movies$Runtime)

diff(range(movies$Runtime))

quantile(movies$Runtime)

quantile(movies$Runtime, 0.95)

IQR(movies$Runtime)

var(movies$Runtime)

sd(movies$Runtime)

# Summarize a quantitative variable
summary(movies$Runtime)

# Qualitative Bivariate Statistics
# (i.e. two categorical variables)
table(genres$Genre, genres$Rating)

# Quantitative Bivariate Statistics
# (i.e. two numeric variables)

# Covarience
cov(movies$Runtime, movies$Box.Office)

cov(movies$Critic.Score, movies$Box.Office)

# Correlation coefficients
cor(movies$Runtime, movies$Box.Office)

cor(movies$Critic.Score, movies$Box.Office)

# Qualitative and Quantitative Bivariate statistics
# (i.e. one categorical and one numeric variable)
tapply(movies$Box.Office, movies$Rating, mean)

tapply(genres$Box.Office, genres$Genre, mean)

# Summarize an entire table
summary(movies)

