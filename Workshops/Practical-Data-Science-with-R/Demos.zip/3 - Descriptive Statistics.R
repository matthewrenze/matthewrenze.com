# Load CSV data
movies <- read.csv("Movies.csv")

genres <- read.csv("Genres.csv")

# Peek at data
head(movies)

head(genres)

# Analyzing One Categorical Variable

# Create a frequency table
table(movies$Rating)

# Analyzing One Numeric Variable

# Analyze central tendancy (location)
mean(movies$Runtime)

median(movies$Runtime)

# Analyze the dispersion (spread)
min(movies$Runtime)

max(movies$Runtime)

range(movies$Runtime)

diff(range(movies$Runtime))

quantile(movies$Runtime)

quantile(movies$Runtime, 0.95)

IQR(movies$Runtime)

var(movies$Runtime)

sd(movies$Runtime)

# Analyze the shape

skewness(movies$Runtime)

kurtosis(movies$Runtime)

# Summarize a quantitative variable
summary(movies$Runtime)

# Analyzing Two Categorical Variables

# Create a contingency table
table(genres$Genre, genres$Rating)

# Analyze Two Numeric Variables

# Measure covarience
cov(movies$Runtime, movies$Box.Office)

cov(movies$Critic.Score, movies$Box.Office)

# Measure correlation coefficients
cor(movies$Runtime, movies$Box.Office)

cor(movies$Critic.Score, movies$Box.Office)

# Analyze a Numeric Variable
# Grouped By an Categorical Variable

# Get average box office by rating (and genre)
tapply(movies$Box.Office, movies$Rating, mean)

tapply(genres$Box.Office, genres$Genre, mean)

# Analyze Many Variables

# Summarize an entire table
summary(movies)

# Create a correlation matrix
cor(movies[, 4:6])

