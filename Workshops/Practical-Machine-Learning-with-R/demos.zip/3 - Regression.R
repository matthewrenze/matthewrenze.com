# Demo 3 - Regression

# Explore the Data

# Load the data
data(iris)

# Create scatterplot matrix
plot(iris[1:4])

# Load corrgram package
library(corrgram)

# Create correlogram
corrgram(iris[1:4])

# Inspect correlation coefficients
cor(iris[1:4])

# Get correlation for petal length vs. width
cor(
  x = iris$Petal.Length, 
  y = iris$Petal.Width)

# Create a scatterplot of petal length vs width
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width,
  xlim = c(0.25, 7),
  ylim = c(0.25, 2.5))

# Split Data into Training and Test Set

# Set seed to make randomness reproducable
set.seed(42)

# Randomly sample 80% of row indexes
indexes <- createDataPartition(
  y = iris$Petal.Width,
  p = 0.80,
  list = FALSE)

# Create training set from indexes
train <- iris[indexes, ]

# Create test set from remaining indexes
test <- iris[-indexes, ]


# Predict with Simple Linear Regression

# Create the simple linear regression model
simpleModel <- lm(
  formula = Petal.Width ~ Petal.Length,
  data = train)

# Draw regression line on plot
lines(
  x = train$Petal.Length,
  y = simpleModel$fitted, 
  col = "red",
  lwd = 3)

# Summarize the model
summary(simpleModel)

# Predict new unknown values from the model
testPredictions <- predict(
  object = simpleModel, 
  newdata = data.frame(
    Petal.Length = c(2, 5, 7)))

# Display predictions
print(testPredictions)

# Plot predictions on scatterplot
points(
  x = c(2, 5, 7),
  y = testPredictions,
  pch = 3,
  col = "blue",
  cex = 5,
  lwd = 5)

# Create predictions with test set
simplePredictions <- predict(
  object = simpleModel,
  newdata = test)

# Plot training set on scatterplot
plot(
  x = train$Petal.Length, 
  y = train$Petal.Width,
  xlim = c(0.25, 7),
  ylim = c(0.25, 2.5))

# Plot predictions on scatterplot
points(
  x = test$Petal.Length,
  y = simplePredictions,
  col = "blue",
  pch = 4,
  lwd = 2)

# Plot correct answers on scatterplot
points(
  x = test$Petal.Length,
  y = test$Petal.Width,
  col = "red",
  pch = 16)

# Plot error on scatterplot
segments(
  x0 = test$Petal.Length,
  x1 = test$Petal.Length,
  y0 = test$Petal.Width,
  y1 = simplePredictions,
  col = "red")

# Compute Root Mean Squared Error for simple linear predictions
simpleRMSE <- sqrt(mean((test$Petal.Width - simplePredictions)^2))

# Print RMSE
print(simpleRMSE)

# Predict with Multiple Linear Regression

# Create multiple linear regression model
multipleModel <- lm(
  formula = Petal.Width ~ .,
  data = train)

# Inspect the model
summary(multipleModel)

# Create predictions with test set
multiplePredictions <- predict(
  object = multipleModel,
  newdata = test)

# Plot training set on scatterplot
plot(
  x = train$Petal.Length, 
  y = train$Petal.Width,
  xlim = c(0.25, 7),
  ylim = c(0.25, 2.5))

# Plot predictions on scatterplot
points(
  x = test$Petal.Length,
  y = multiplePredictions,
  col = "blue",
  pch = 4,
  lwd = 2)

# Plot correct answer on scatterplot
points(
  x = test$Petal.Length,
  y = test$Petal.Width,
  col = "red",
  pch = 16)

# Plot error on scatterplot
segments(
  x0 = test$Petal.Length,
  x1 = test$Petal.Length,
  y0 = test$Petal.Width,
  y1 = multiplePredictions,
  col = "red")

# Compute RMSE for model
multipleRMSE <- sqrt(mean((test$Petal.Width - multiplePredictions)^2))

# Display RMSE for model
print(multipleRMSE)

# Predict with Neural Network Regression

# Create a function to scale and center
normalize <- function(x) {
  (x - min(x)) / (max(x) - min(x)) - 0.5
}

# Create a function to undo scale and center
denormalize <- function(x, y) {
  ((x + 0.5) * (max(y) - min(y))) + min(y)
}

# Scale iris data set
scaledIris <- data.frame(
  Sepal.Length = normalize(iris$Sepal.Length),
  Sepal.Width = normalize(iris$Sepal.Width),
  Petal.Length = normalize(iris$Petal.Length),
  Petal.Width = normalize(iris$Petal.Width),
  Species = as.numeric(iris$Species) - 2)

# Create training set from indexes
scaledTrain <- scaledIris[indexes, ]

# Create test set from remaining indexes
scaledTest <- scaledIris[-indexes, ]

# Create a neural network regressor
neuralRegressor <- nnet(
  formula = Petal.Width ~ .,
  data = scaledTrain,
  linout = TRUE,
  skip = TRUE,
  size = 4,
  decay = 0.0001,
  maxit = 500)

# Load neural net tools
library(NeuralNetTools)

# Plot the neural network
plotnet(neuralRegressor)

# Predict new values 
scaledPredictions <- predict(
  object = neuralRegressor, 
  newdata = scaledTest)

# Denormalize predictions
neuralPredictions <- denormalize(
  x = scaledPredictions, 
  y = iris$Petal.Width)

# Plot training on scatterplot
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width,
  xlim = c(0.25, 7),
  ylim = c(0.25, 2.5))

# Plot predictions on scatterplot
points(
  x = test$Petal.Length,
  y = neuralPredictions,
  col = "blue",
  pch = 4,
  lwd = 2)

# Plot correct answer on scatterplot
points(
  x = test$Petal.Length,
  y = test$Petal.Width,
  col = "red",
  pch = 16)

# Plot error on scatterplot
segments(
  x0 = test$Petal.Length,
  x1 = test$Petal.Length,
  y0 = test$Petal.Width,
  y1 = neuralPredictions,
  col = "red")

# Compute RMSE for neural regression
neuralRMSE <- sqrt(mean((test$Petal.Width - neuralPredictions)^2))

# Display RMSE for neural regression
print(neuralRMSE)

# Compare RMSE for all three models
print(simpleRMSE)
print(multipleRMSE)
print(neuralRMSE)
