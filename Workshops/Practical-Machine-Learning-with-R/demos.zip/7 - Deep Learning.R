# Demo 7 - Deep Learning

# Set the working directory
setwd("C:/Users/Matthew/Dropbox/Professional/Workshops/Practical Machine Learning with R/Demos/MNIST")

# Load the MNIST data set
mnist <- read.csv('mnist.csv')

# Inspect the number of rows
nrow(mnist)

# Inspect the number of columns
ncol(mnist)

# Inspect the first few rows and columns
mnist[c(1:6), c(1:6)]

# Create a function to display an image
display_image <- function(values) {
  
  # Convert the row of data into a matrix
  first_image <- matrix(
    data = as.numeric(values),
    nrow = 28, 
    ncol = 28)
  
  # Display the matrix as an image
  image(
    x = 1:28, 
    y = 1:28, 
    z = first_image[,28:1], 
    col = gray((0:255) / 255))
}

# Inspect the first few images
display_image(mnist[1, -1])
display_image(mnist[2, -1])
display_image(mnist[3, -1])

# Scale the feature from [0-256] to [0-1]
mnist[, -1] <- mnist[, -1] / 255

# Split the Data into Training and Test Set

# Set the seed to make randomness reproducable
set.seed(42)

# Load the caret package
library(caret)

# Randomly sample 80% of the row indexes
indexes <- createDataPartition(
  y = mnist$Label,
  p = 0.80,
  list = FALSE)

# Create a training set from indexes
train <- mnist[indexes, ]

# Create a test set from remaining indexes
test <- mnist[-indexes, ]

# Convert the training set to a matix
train <- data.matrix(train)

# Convert the test set to matix
test <- data.matrix(test)

# Assign the training features
train.X <- train[, -1]

# Assign the training labels
train.y <- train[, 1]

# Transpose the training features
train.X <- t(train.X)

# Assign the test features
test.X <- test[,-1]

# Assign the test labels
test.y <- test[,1]

# Transpose the test features
test.X <- t(test.X)

# Construct a fully-connected deep neural network
# (in) -> (128-relu) -> (64-relu) -> (10-softmax)

# Load the MXNet package
library(mxnet)

# Create the input layer
data <- mx.symbol.Variable("data")

# Create the 1st fully-connected hidden layer
fc1 <- mx.symbol.FullyConnected(
  data = data, 
  name = "fc1", 
  num_hidden = 128)

# Create the 1st activation function (relu)
act1 <- mx.symbol.Activation(
  data = fc1, 
  name = "relu1", 
  act_type = "relu")

# Create the 2nd fully-connected hidden layer
fc2 <- mx.symbol.FullyConnected(
  data = act1, 
  name = "fc2", 
  num_hidden = 64)

# Create the 2nd activation function (relu)
act2 <- mx.symbol.Activation(
  data = fc2, 
  name = "relu2", 
  act_type = "relu")

# Create the output layer
fc3 <- mx.symbol.FullyConnected(
  data = act2, 
  name = "fc3",
  num_hidden = 10)

# Create the output activation function (softmax)
softmax <- mx.symbol.SoftmaxOutput(
  data = fc3, 
  name = "sm")

# Set the MXNet random seed
mx.set.seed(0)

# Train the model
model <- mx.model.FeedForward.create(
  symbol = softmax, 
  X = train.X, 
  y = train.y,
  ctx = mx.cpu(), 
  num.round = 10, 
  array.batch.size = 100,
  array.layout = "colmajor",
  learning.rate = 0.07, 
  momentum = 0.9,  
  eval.metric = mx.metric.accuracy,
  initializer = mx.init.uniform(0.07),
  epoch.end.callback = mx.callback.log.train.metric(100))

# Make predictions
predictions <- predict(
  model = model, 
  X = test.X,
  array.layout = "colmajor")

# Inspect the predictions (10 rows and 5 columns)
predictions[c(1:10), c(1:5)]

# Transpose the predictions
predictions <- t(predictions)

# Inspect the predictions (5 rows and 10 columns)
predictions[c(1:5), c(1:10)]

# Convert the probabilites into classes
predictions <- max.col(predictions) - 1

# Inspect the predictions (5 rows and 10 columns)
head(predictions)

# Inspect the correct answers from test data set
head(test.y)

# Inspect the first few test images
display_image(test.X[, 1])
display_image(test.X[, 2])
display_image(test.X[, 3])

# Evaluate the prediction accuracy
confusionMatrix(
  data = predictions,
  reference = test.y)


