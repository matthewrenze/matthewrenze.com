# Demo 8 - Reinforcement Learning: Grid World 2x2

# Load the Reinforcement Learning package
library(ReinforcementLearning)

# Define the states
states <- c("s1", "s2", "s3", "s4")

# Define the actions
actions <- c("up", "down", "left", "right")

# Define a function implementing a 2x2 grid-world environment
env <- gridworldEnvironment

# Inspect the environment code
print(env)

# Verify the environment behaves as expected
print(env("s1", "down"))
print(env("s2", "right"))
print(env("s3", "up"))

# Set the random number seed
set.seed(8)

# Sample 1000 random experiences from the environment
data <- sampleExperience(
  N = 1000, 
  env = env, 
  states = states, 
  actions = actions,
  actionSelection = "random")

# Inspect the experience samples
head(data)

# Define the reinforcement-learning parameters
control <- list(
  alpha = 0.1, 
  gamma = 0.5, 
  epsilon = 0.1)

# Perform reinforcement learning
model <- ReinforcementLearning(
  data, 
  s = "State", 
  a = "Action", 
  r = "Reward", 
  s_new = "NextState", 
  control = control)

# Print the result
print(model)

# Sample 1000 experiences from the environment 
# using previously learned knowledge
data_new <- sampleExperience(
  N = 1000, 
  env = env, 
  states = states, 
  actions = actions, 
  actionSelection = "epsilon-greedy", 
  control = control,
  model = model)

# Inspect the new data
head(data_new)

# Update the model with the new experiences
model_new <- ReinforcementLearning(
  data_new, 
  s = "State", 
  a = "Action", 
  r = "Reward", 
  s_new = "NextState",
  iter = 3,
  control = control, 
  model = model)

# Print the result
print(model_new)

# Summarize the model
summary(model_new)

# Plot the model
plot(model_new)

# Test the agent

# Choose an action at s1
epsilonGreedyActionSelection(
  Q = model_new$Q_hash,
  state = "s1",
  epsilon = 0)

# Choose an action at s2
epsilonGreedyActionSelection(
  Q = model_new$Q_hash,
  state = "s2",
  epsilon = 0)

# Choose an action at s3
epsilonGreedyActionSelection(
  Q = model_new$Q_hash,
  state = "s3",
  epsilon = 0)
