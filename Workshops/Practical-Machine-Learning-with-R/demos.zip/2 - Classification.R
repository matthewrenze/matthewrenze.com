# Demo 2 - Classification

# Set the working directory
setwd("C:/Users/Matthew/Dropbox/Professional/Workshops/Practical Machine Learning with R/Data")

# Load Iris data
iris <- read.csv("Iris.csv")

# Inspect the data
head(iris)

# Load color brewer library
library(RColorBrewer)

# Create a color palette
palette <- brewer.pal(3, "Set2")

# Create a scatterplot matrix colored by species
plot(
  x = iris[1:4], 
  col = palette[as.numeric(iris$Species)],
  pch = 19)

# View scatterplot of petal length vs width
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = palette[as.numeric(iris$Species)],
  pch = 19)

# Create Training and Test Sets

# Set seed to make randomness reproducable
set.seed(42)

# Randomly sample 100 of 150 row indexes
indexes <- sample(
  x = 1:150, 
  size = 100)

# Create training set from indexes
train <- iris[indexes, ]

# Create test set from remaining indexes
test <- iris[-indexes, ]

# Predict with K-Nearest Neighbors

# Load the caret package
library(caret)

# Train knn model
knnModel <- knn3(
  formula = Species ~ .,
  data = train,
  k = 3)

# Predict with model
knnPredictions <- predict(
  object = knnModel,
  newdata = test,
  type = "class")

# Summarize prediction results
table(
  x = knnPredictions, 
  y = test$Species)

# Create confusion matrix
knnMatrix <- confusionMatrix(
  data = knnPredictions, 
  reference = test$Species)

# Inspect results
print(knnMatrix)

# Plot training set (solid dots)
plot(
  x = train$Petal.Length, 
  y = train$Petal.Width, 
  col = palette[as.numeric(train$Species)],
  pch = 19)

# Plot predictions (circle) and misclass (X)
points(
  x = test$Petal.Length, 
  y = test$Petal.Width, 
  col = palette[as.numeric(knnPredictions)],
  pch = ifelse(knnPredictions == test$Species, 1, 4))

# Predict using Decision Tree

# Load decision tree package
library(tree)

# Train tree model
treeModel <- tree(
  formula = Species ~ .,
  data = train)

# Inspect the model
summary(treeModel)

# Plot the tree model
plot(treeModel)
text(treeModel)

# Create a scatterplot colored by species
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width,
  pch = 19,
  col = palette[as.numeric(iris$Species)],
  main = "Iris Petal Length vs. Width",
  xlab = "Petal Length (cm)",
  ylab = "Petal Width (cm)")

# Plot the decision boundaries
partition.tree(
  tree = treeModel,
  label = "Species",
  add = TRUE)

# Predict with model
treePredictions <- predict(
  object = treeModel,
  newdata = test,
  type = "class")

# Create confusion matrix
treeMatrix <- confusionMatrix(
  data = treePredictions, 
  reference = test$Species)

# Inspect results
print(treeMatrix)

# Predict with Neural Network

# Load Neural Network package
library(nnet)

# Train neural network model
neuralModel <- nnet(
  formula = Species ~ .,
  data = train,
  size = 4,
  decay = 0.0001,
  maxit = 500)

# Inspect the model
summary(neuralModel)

# Load neural net tools
library(NeuralNetTools)

# Plot the neural network
plotnet(neuralModel, alpha = 0.5)

# Predict with model
neuralPredictions <- predict(
  object = neuralModel,
  newdata = test[, 1:4],
  type = "class")

# Create confusion matrix
neuralMatrix <- confusionMatrix(
  data = neuralPredictions, 
  reference = test$Species)

# Inspect results
print(neuralMatrix)

# Compare accuracy of classifiers
print(knnMatrix$overall[1])
print(treeMatrix$overall[1])
print(neuralMatrix$overall[1])
