# Demo 5 - ML in Practice

# Set working directory
setwd("C:/Users/Matthew/Dropbox/Professional/Workshops/Practical Machine Learning with R/Data")

# Read Titanic.csv file
raw <- read.csv("Titanic.csv")

# Peek at the data
head(raw)

# Explore data set
summary(raw)

# Load corrgram package
library(corrgram)

# Visualize corellations
corrgram(raw)

# Inspect missing values
sum(is.na(raw))

# Load dplyr
library(dplyr)

# Transform, clean, engineer, and select features
clean <- raw %>%
  mutate(age = ifelse(is.na(age), mean(na.omit(age)), age)) %>%
  mutate(family = sibsp + parch) %>%
  mutate(survived = as.factor(ifelse(survived == 0, "No", "Yes"))) %>%
  select(
    Class = pclass,
    Sex = sex,
    Age = age,
    Family = family,
    Survived = survived) %>%
  as.data.frame()

# Inspect at the data
head(clean)

# Load caret package
library(caret)

# Set random seed
set.seed(42)

# Create training set
indexes <- createDataPartition(
  y = clean$Survived, 
  p = .8, 
  list = FALSE, 
  times = 1)

# Create training set
train <- clean[indexes, ]

# Create test set
test <- clean[-indexes, ]

# Specify preprocessing
preProcess <- c("center", "scale")

# Specify training control parameters
control <- trainControl(
  method = "cv",
  number = 10)

# Create k-nearest neighbor model
knnModel <- train(
  form = Survived ~ .,
  data = train,
  method = "knn",
  preProcess = preProcess,
  trControl = control,
  tuneLength = 5,
  metric = "Accuracy")

# Display model details
print(knnModel)

# Plot model accuracy
plot(knnModel)

# Create decision tree
treeModel <- train(
  form = Survived ~ .,
  data = train,
  method = "rpart",
  preProcess = preProcess,
  trControl = control,
  tuneLength = 5,
  metric = "Accuracy")

# Display model summary
print(treeModel)

# Plot model accuracy
plot(treeModel)

# Specify hyperparameter-tuning grid
neuralTuneGrid <- data.frame(
  size = c(3, 4, 5, 3, 4, 5, 3, 4, 5),
  decay = c(0.1, 0.1, 0.1, 0.01, 0.01, 0.01, 0.001, 0.001, 0.001))

# Create neural network model
neuralModel <- train(
  form = Survived ~ .,
  data = train,
  method = "nnet",
  preProcess = preProcess,
  trControl = control,
  tuneGrid = neuralTuneGrid)

# Display model summary
print(neuralModel)

# Plot model accuracy
plot(neuralModel)

# Combine results
results <- resamples(list(
  knn = knnModel,
  tree = treeModel,
  nnet = neuralModel))

# Summarize results
summary(results)

# Create dot plot to compare top models
dotplot(results)

# Create box plot to compare models
bwplot(results)

# Create density plot to compare models
densityplot(results, auto.key = TRUE)

# Make final predictions using hold-out test set
final_predictions <- predict(
  object = treeModel,
  newdata = test)

# Determine final prediction accuracy
finalMatrix <- confusionMatrix(
  data = final_predictions,
  reference = test$Survived)

# Inspect final prediction accuracy
print(finalMatrix)

# Question: How likely is it that Jack survives?
predict(
  object = neuralModel,
  newdata = data.frame(
    Class = 3,
    Sex = "male",
    Age = 20, 
    Family = 0),
  type = "prob")

# Just for fun: Would I survive the Titanic?
predict(
  object = neuralModel,
  newdata = data.frame(
    Class = 3,
    Sex = "male",
    Age = 39, 
    Family = 1),
  type = "prob")
