# Demo 4 - Clustering

# Explore the data

# Load Iris data
data(iris)

# Load color brewer library
library(RColorBrewer)

# Create a color palette
palette <- brewer.pal(3, "Set2")

# Create a scatterplot matrix
plot(
  x = iris[1:4],
  pch = 19)

# View scatterplot of petal length vs width
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width,
  pch = 19)

# Create clusters with k-Means

# Set seed to make randomness reproducable
set.seed(42)

# Create k-means clusters
clusters <- kmeans(
  x = iris[, 1:4], 
  centers = 3, 
  nstart = 10)

# Plot each cluster as a shape
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  pch = clusters$cluster)

# Plot each clusters and color by species
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = palette[as.numeric(iris$Species)], 
  pch = clusters$cluster)

# Plot centroid of clusters
points(
  x = clusters$centers[, "Petal.Length"], 
  y = clusters$centers[, "Petal.Width"],
  pch = 4, 
  lwd = 4, 
  col = "blue")

# View confusion matrix
table(
  x = clusters$cluster, 
  y = iris$Species)

# Create Hierachical Clusters

# Create hierachical clusters
hclusters <- hclust(dist(iris[ ,1:4]))

# Set labels to species
hclusters$labels <- as.numeric(iris$Species)

# Plot dendorogram of clusters
plot(hclusters)

# Cut tree into three clusters
cuts <- cut(
  x = as.dendrogram(hclusters), 
  h = 4)

# Plot upper branches
plot(cuts$upper)

# Plot first cluster
plot(cuts$lower[[1]])

# Plot second cluster
plot(cuts$lower[[2]])

# Plot third cluster
plot(cuts$lower[[3]])

# Get clusters as vector
cuts2 <- cutree(
  tree = hclusters, 
  k = 3)

# Create confusion matrix
table(
  x = cuts2,
  y = iris$Species)

# Plot clusters and color by species
plot(
  x = iris$Petal.Length, 
  y = iris$Petal.Width, 
  col = palette[as.numeric(iris$Species)], 
  pch = cuts2)
