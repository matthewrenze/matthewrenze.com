# Demo 6 - Ensemble Learning

# Set the working directory
setwd("C:/Users/Matthew/Dropbox/Professional/Workshops/Practical Machine Learning with R/Data")

# Load Sonar.csv into a dataframe
sonar <- read.csv("Sonar.csv")

# Split the Data into Training and Test Set

# Load the caret package
library(caret)

# Set the seed to make randomness reproducable
set.seed(42)

# Randomly sample 80% of the row indexes
indexes <- createDataPartition(
  y = sonar$Class,
  p = 0.70,
  list = FALSE)

# Create a training set from indexes
train <- sonar[indexes, ]

# Create a test set from remaining indexes
test <- sonar[-indexes, ]

# Create a Single Decision Tree Classifier

# Load the tree package
library(tree)

# Create a single decision tree
treeModel <- tree(
  formula = Class ~ .,
  data = train)

# Plot the decision tree
plot(treeModel)
text(treeModel)

# Create predictions with the test set
treePredictions <- predict(
  object = treeModel,
  newdata = test,
  type = "class")

# Compute the accuracy
treeMatrix <- confusionMatrix(
  data = treePredictions,
  reference = test$Class)

# Inspect the accuracy
print(treeMatrix)

# Create a Random Forest Classifier

# Load the random forest package
library(randomForest)

# Create a random forest classifier
rfModel <- randomForest(
  formula = Class ~ .,
  data = train,
  ntree = 1000)

# Display the model details
print(rfModel)

# Plot the model accuracy
plot(rfModel)

# Create predictions with test set
rfPredictions <- predict(
  object = rfModel,
  newdata = test,
  type = "class")

# Compute the accuracy
rfMatrix = confusionMatrix(
  data = rfPredictions,
  reference = test$Class)

# Inspect the accuracy
print(rfMatrix)

# Compare the accuracy
treeMatrix[[3]][1]
rfMatrix[[3]][1]
