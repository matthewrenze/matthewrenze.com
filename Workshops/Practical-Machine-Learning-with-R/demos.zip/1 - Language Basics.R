# Demo 1 - Language Basics

# Assign to a variable
x <- "Hello World!"

# Print a variable
print(x)

# NOTE: IDE Walkthrough

# Create a vector
v <- c(1, 2, 3)

# Print a vector
print(v)

# Creating a data frame
df <- data.frame(
  Name = c("Cat", "Dog", "Cow", "Pig"), 
  HowMany = c(5, 10, 15, 20),
  IsPet = c(TRUE, TRUE, FALSE, FALSE))

# Print a data frame
print(df)

# Index by row and column
df[1, 2]

# Index by row ID
df[1, ]

# Index by column ID
df[, 2]

# Index a column name
df$HowMany

# Subset rows
df[df$HowMany > 12, ]
