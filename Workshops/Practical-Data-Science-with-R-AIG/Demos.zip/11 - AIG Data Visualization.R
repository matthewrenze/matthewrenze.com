### Create Data Visualizations for Policy Data

# Set the working directory
setwd("C:/Workshop/Data")

# Read the policy CSV file into a data frame caled "policies"
policies <- read.csv("Policies.csv")

### Problem 1: Visualizing One Categorical Variable

# Create a frequency bar chart of Blood Type
plot(
    x = policies$BloodType,
    main = "Frequency of Policies by Blood Type",
    xlab = "Blood Type",
    ylab = "Count of Policies")

# Question: Which blood type is most common?

### Problem 2: Visualizing One Numeric Variable

# Create a dot plot of height (Centimeters)
plot(
    x = policies$Centimeters, 
    y = rep(0, nrow(policies)), 
    main = "Distribution of Policy Holder Heights",
    xlab = "Height (cm)",
    ylab = "", 
    yaxt = "n")

# Create a boxplot of height (Centimeters)
boxplot(
    x = policies$Centimeters, 
    main = "Distribution of Policy Holder Heights",
    xlab = "Height (cm)",
    horizontal = TRUE)

# Create a histogram of height (Centimeters)
hist(
    x = policies$Centimeters,
    main = "Distribution of Policy Holder Heights",
    xlab = "Height (cm)",
    ylab = "Frequency")

# Create a density plot of height (Centimeters)
plot(
    x = density(policies$Centimeters),
    main = "Distribution of Policy Holder Heights",
    xlab = "Height (cm)",
    ylab = "Density")

# Add dot plot to base of density plot
points(
    x = policies$Centimeters, 
    y = rep(-0.0005, nrow(policies)))

# Question: Is this distribution roughly symetric?

### Problem 3: Visualizing Two Categorical Variables

# Create a spineplot of Blood Type and Gender
spineplot(
    x = policies$BloodType, 
    y = policies$Gender,
    main = "Frequency of Movies by Blood Type and Gender",
    xlab = "Blood Type",
    ylab = "Gender")

# Create a mosaic plot of genre and rating
mosaicplot(
    x = table(
        policies$BloodType, 
        policies$Gender),
    las = 3,
    main = "Frequency of Movies by Blood Type and Gender",
    xlab = "Blood Type",
    ylab = "Gender")

# Question: What appears to be the least common blood type for males?

### Problem 4: Visualizing Two Numeric Variables

# Create a scatterplot of weight (Kilograms) and height (Centimeters)
plot(
    x = policies$Kilograms, 
    y = policies$Centimeters,
    main = "Correlation between Weight and Height",
    xlab = "Weight (kilograms)",
    ylab = "Height (centimeters)")

# Create a scatterplot of Rate and Age
plot(
    x = policies$Age, 
    y = policies$Rate,
    main = "Correlation between Mortality Rate and Age",
    xlab = "Age (years)",
    ylab = "Mortality Rate")

# Question: Does there appear to be any pattern in either of these plots?

### Problem 5: Visualize a Time Series

# Plot a line graph of mortality rate by age
# NOTE: Using Age as proxy for Date of Birth
# Note: Create the array using tapply first, then set x to the names and y to the values
timeseries <- tapply(policies$Rate, policies$Age, mean)

plot(
    x = names(timeseries),
    y = timeseries,
    type = "l",
    main = "Mortality Rate by Age",
    xlab = "Age (years)",
    ylab = "Mortality Rate")

# Question: Why is there a steep decline at 85?

### Problem 6: Visualizing a Numeric Variable 
### Grouped By a Categorical Variable

# Create a bar graph of Rate by Gender
barplot(
    height = tapply(policies$Rate, policies$Gender, mean),
    main = "Average Mortality Rate by Gender",
    xlab = "Gender",
    ylab = "Mortality Rate")

# Create a bar graph of average Height by Blood Type
barplot(
    height = tapply(policies$Centimeters, policies$BloodType, mean),
    las = 3,
    main = "Average Height by Blood Type",
    ylab = "Height (cm)",
    xlab = "Blood Type")

# Question: How are height and blood type related?

### Problem 7: Visualizing Many Variables

# Create a scatterplot matrix of Age, Kilograms, Centimeters, and Rate
plot(policies[, c(21, 38, 40, 44)])

# Load corrgram package
library(corrgram)

# Create a correlogram of Age, Kilograms, Centimeters, and Rate
corrgram(policies[, c(21, 38, 40, 44)])

# Question: Which two variables have the strongest correlation?
