### Transform and clean Policy Data

# Set the working directory
setwd("C:/Workshop/Data")

# Read the Males.csv file into a data frame called "males"
males <- read.csv("Males.csv")

# Inspect the data
head(males)

# Read the Females.csv file into a data frame called "females"
females <- read.csv("Females.csv")

# Inspect the data
head(females)

# Union male and females into a single date frame called "policies"
# NOTE: Look at either union in dplyr or the rbind command
policies <- rbind(males, females)

# Check to see if there are any rows with NA values
sum(is.na(policies))

# Inspect the levels of the factor variable Gender in policies
levels(policies$Gender)

# Rename the levels to "Male" and "Female" (i.e. capitalize them) 
levels(policies$Gender) <- c("Male", "Female")

# Verify renamed factor levels
levels(policies$Gender)

# Create a column called Rate by joining mortality rates data to policies
# NOTE: This is difficult so just use the following commands
# Note: This might take a minute or two
policyRates <- mapply(
    getRate, 
    as.character(policies$StateFull),
    as.character(policies$Gender),
    policies$Age,
    SIMPLIFY = TRUE)

policies$Rate <- unlist(
    x = policyRates, 
    use.names = FALSE)

# Inspect the first six policy rates
head(policies$Rate)

# Count the NaN (Not a Number) values in Rate column
sum(is.nan(policies$Rate))

# Replace the NaN values with zeros (numeric)
policies$Rate[is.nan(policies$Rate)] = 0 

# Verify the NaN replacements
sum(is.nan(policies$Rate))

# Save file as "Policies 2.csv"
write.csv(
    x = policies, 
    file = "Policies 2.csv",
    row.names = FALSE)

# Inspect the newly created file