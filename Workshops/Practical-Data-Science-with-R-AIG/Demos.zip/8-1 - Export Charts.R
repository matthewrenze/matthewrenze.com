# Exporting Charts

# Load the iris data set
data(iris)

# Create a plot
plot(
    x = iris$Petal.Length, 
    y = iris$Petal.Width, 
    col = as.numeric(iris$Species))

# Export the plot using RStudio's export tool