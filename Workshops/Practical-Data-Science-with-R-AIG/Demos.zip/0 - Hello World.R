# Assign a character string to a variable
x <- "Hello World!"

# Print the variable
print(x)

# NOTE: Walkthrough IDE
