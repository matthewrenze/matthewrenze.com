### Make Predictions using Machine Learning

# Set the working directory
setwd("C:/Workshop/Data")

# Load policies from the CSV file
policies <- read.csv("Policies.csv")

# Set the seed to make randomness reproducable
set.seed(123)

### Problem 1: Prepare the Data

# Create a dataset called "full" containing just Gender, State,  Age, and Rate
full <- policies %>%
    select(Gender, State, Age, Rate) %>%
    as.data.frame()

# Inspect the first six rows
head(full)

# Eliminate rows containing NA values
full <- na.omit(full)
    
# Find the average rate
mean(full$Rate)

# Create a categorical variable called "Risk" with two classes (i.e. High and Low)
# Use "Low" if less than or equal to average Rate and "High" if greater than average Rate
full$Risk[full$Rate <= mean(full$Rate)] <- "Low"
full$Risk[full$Rate > mean(full$Rate)] <- "High"

# Convert Risk to a factor variable
full$Risk <- factor(full$Risk)

# Remove the Rate column
# Hint set the column equal to NULL
full$Rate <- NULL

# Inspect the first six rows
head(full)
    
# Randomly sample 1500 out of the 2000 row indexes
indexes <- sample(
    x = 1:2000, 
    size = 1500)

# Create a training set called "train" from the indexes
train <- full[indexes, ]

# Create a test set called "test" from the remaining indexes
test <- full[-indexes, ]

### Problem 2: Predict using a Decision Tree

# Load the tree package
library(tree)

# Train the decision tree model with "Risk ~ Gender + Age"
# NOTE: We can't use State because tree only suports 32 levels in predictor variables
treeModel <- tree(
    formula = Risk ~ Gender + Age,
    data = train)

# Inspect the model
summary(treeModel)

# Plot the model
plot(treeModel)
text(treeModel)

# Question: How do you interpret this model?

# Predict the test data set with the model
treePredictions <- predict(
    object = treeModel,
    newdata = test,
    type = "class")

# Summarize the prediction accuracy
table(
    x = treePredictions, 
    y = test$Risk)

# Load the caret package
library(caret)

# Evaluate the prediction results
confusionMatrix(
    data = treePredictions, 
    reference = test$Risk)

# Note the accuracy
confusionMatrix(
    data = treePredictions, 
    reference = test$Risk)[3]$overall[1]


### Problem 3: Predict using a Naive Bayes Classifier

# Load the e1071 package
library(e1071)

# Train the model
bayesModel <- naiveBayes(
    formula = Risk ~ ., 
    data = train)

# Inspect the model
summary(bayesModel)

# Predict with the model
bayesPredictions <- predict(
    object = bayesModel, 
    newdata = test[, 1:3])

# Evaluate the prediction results
confusionMatrix(
    data = bayesPredictions, 
    reference = test$Risk)

# Note the accuracy
confusionMatrix(
    data = bayesPredictions, 
    reference = test$Risk)[3]$overall[1]


### Problem 4: Predict with a Neural Network

# Load the nnet package
library(nnet)

# Train the model with size = 3, decay = 0.0001, and maxit = 500
neuralModel <- nnet(
    formula = Risk ~ .,
    data = train,
    size = 3,
    decay = 0.0001,
    maxit = 500)

# Inspect the model
summary(neuralModel)

# Predict with the model
neuralPredictions <- predict(
    object = neuralModel,
    newdata = test[, 1:3],
    type = "class")

# Evaluate the prediction results
confusionMatrix(
    data = neuralPredictions, 
    reference = test$Risk)

# Note the accuracy
confusionMatrix(
    data = neuralPredictions, 
    reference = test$Risk)[3]$overall[1]

# Question: Which algorithm provides the highest accuracy?

# Question: Which algorithm provides the most transparency?
