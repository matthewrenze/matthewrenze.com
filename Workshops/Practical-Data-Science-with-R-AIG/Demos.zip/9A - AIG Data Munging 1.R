### Transform and clean Mortality Statistics

# Set the working directory
setwd("C:/Workshop/Data")

# Read the tab-delimited mortality statistics file into a data set called "rates"
rates <- read.table(
    file = "Mortality Statistics.txt",
    sep = "\t", 
    header = TRUE,
    quote = "\"")

# Inspect the data
head(rates)

### Problem 1: Rename the Age Group Column

# Inspect the name of the Age Group column (i.e the fifth column)
names(rates)[5]

# Rename "Five.Year.Age.Groups" to "Age.Group"
names(rates)[5] <- "Age.Group"

# Verify rename
names(rates)[5]

### Problem 2: Convert Rate from Percentage to Decimal

# Inspect the data type of the Rate column
class(rates$Rate)

# Convert Rate to a character string
rates$Rate <- as.character(rates$Rate)

# Eliminate the percent sign from the Rate values
rates$Rate <- gsub(
    pattern = "%", 
    replacement = "",
    x = rates$Rate)

# Convert "#VALUE!" in Rate to an empty string (i.e. "")
rates$Rate <- gsub(
    pattern = "#VALUE!", 
    replacement = "",
    x = rates$Rate)

# Cast Rate to numeric 
rates$Rate <- as.numeric(rates$Rate)

# Verify Rate column is numeric
class(rates$Rate)

# Convert Rate from percent to decimal 
# (i.e. multiply by 0.01)
rates$Rate <- rates$Rate * 0.01

# Inspect the first six rows
head(rates$Rate)

# Inspect the last six rows
tail(rates$Rate)

### Problem 3: Eliminate rows with NA values

# Count the rows with NA values
sum(is.na(rates))

# Eliminate the rows with NA values
rates <- na.omit(rates)

# Verify that the NA rows have been omitted
sum(is.na(rates))

### Problem 4: Create High and Low Age Range Columns

# Inspect the unique values in the Age Group column
unique(rates$Age.Group)

# Inspect unique values in Five-Year Age Group Codes column
unique(rates$Five.Year.Age.Groups.Code)

# Decide which column to use to create your high and low age columns
# Question: Why did you choose this column?

# Create a function to extract the low value from each age group
# Note: use 0 for "< 1 year"
# Note: use NA for "Not Stated"
getLowAge <- function(group)
{
    if (group == "Not Stated"){
        NA
    }
    else if (group == "< 1 year") {
        0
    }
    else if (group == "100+ years") {
        100
    }
    else {
        as.integer(sub("-.*", "", group))
    }
}

# Apply the function to create a column called "Age.Group.Low"
rates$Age.Group.Low <- sapply(
    X = rates$Age.Group,
    FUN = getLowAge)

# Inspect the first six Age.Group.Low rows
head(rates$Age.Group.Low)

# Create a function to extract the high value from each age group
# Note: use 999 for "100+ years"
# Note: use NA for "Not Stated"
getHighAge <- function(group)
{
    if (group == "Not Stated") {
        NA
    }
    else if (group == "< 1 year") {
        1
    }
    else if (group == "100+ years") {
        999
    }
    else {
        as.integer(gsub("[a-z]|\\s|.*-", "", group))
    }
}

# Apply the function to create a column called "Age.Group.High"
rates$Age.Group.High <- sapply(
    X = rates$Age.Group,
    FUN = getHighAge)

# Inspect the first six Age.Group.High rows
head(rates$Age.Group.High)

# Save the data frame as a CSV file called "Mortality Rates 2.csv"
write.csv(
    x = rates, 
    file = "Mortality Rates 2.csv",
    row.names = FALSE)

# Inspect the newly created CSV file

# Problem 5: Compute the Mortality Rate for an Individual

# Load the dplyr library
library(dplyr)

# Use dplyr to find the average mortality rate for 38-year old male from Iowa
# NOTE: It might be best to do this step-by-step first
# NOTE: The equivalent SQL would be
# select avg(Rate)
# from [mortality]
# where State = "Iowa"
#   and Gender = "Male"
#   and Age.Group.Low >= 38
#   and Age.Group.High <= 38
rates %>%
    filter(State == "Iowa") %>%
    filter(Gender == "Male") %>%
    filter(Age.Group.Low <= 38) %>%
    filter(Age.Group.High >= 38) %>%
    summarise(AvgRate = mean(Rate)) %>%
    select(AvgRate)

# Create a function called "getRate" to return the average mortality rate given state, gender, and age
getRate <- function(state, gender, age) {
    rates %>%
        filter(State == state) %>%
        filter(Gender == gender) %>%
        filter(Age.Group.Low <= age) %>%
        filter(Age.Group.High >= age) %>%
        summarise(AvgRate = mean(Rate)) %>%
        select(AvgRate)
}

# Use this function to calculate the rate for a 20-year old female from New York
getRate("New York", "Female", 20)

# Question: Who has the higher mortality rate?
