### Create Statistical Models

# Set working directory
setwd("C:/Workshop/Data")

# Load policies from the CSV file
policies <- read.csv("Policies.csv")

### Problem 1: Create a Gaussian Distribution Model of Height

# Create a plot of height (Centimeters)
plot(density(policies$Centimeters))

# Get the mean
mean(policies$Centimeters)

# Get the standard deviation
sd(policies$Centimeters)

# Generate/predict new values from the model
values <- rnorm(
    n = 1000,
    mean = mean(policies$Centimeters),
    sd = sd(policies$Centimeters))

# Create a plot of the generated values
plot(density(values))

# Get the mean of the generated values
mean(values)

# Get the standard deviation of the generated values
sd(values)

# Question: What would happen to the mean and standard deviation if we increase n to 1,000,000?

### Problem 2: Create a Simple Linear Regression Model

# Create a scatterplot of height (Centimeters) vs weight (Kilograms)
plot(
    x = policies$Centimeters, 
    y = policies$Kilograms)

# Create a linear regression model
x <- policies$Centimeters

y <- policies$Kilograms

model <- lm(y ~ x)

# Draw the linear regression model on the plot
lines(
    x = policies$Centimeters,
    y = model$fitted, 
    col = "red",
    lwd = 3)

# Get correlation coefficient
cor(
    x = policies$Centimeters, 
    y = policies$Kilograms)

# Summarize the model
summary(model)

# Predict new unknown weights based on the following heights: 25, 50, 75
predict(
    object = model, 
    newdata = data.frame(
        x = c(150, 175, 200)))

# Question are their any problems with this linear regression model?

# Create a scatterplot of Age vs Rate
plot(
    x = policies$Age, 
    y = policies$Rate)
	
# Get the correlation coefficient
cor(
    x = policies$Age,
    y = policies$Rate)

# Question: Why is a linear model not a good model for these data?