### Create Descriptive Statistics for Mortality Rates

# Set the working directory
setwd("C:/Workshop/Data")

# Read the mortality rates CSV file into a data frame called "rates"
rates <- read.csv("Mortality Rates.csv")

### Problem 1: Analyze One Categorical Variable

# Create a frequency table for Gender
summary(rates$Gender)

# Question: Which gender has more mortality rate records?

### Problem 2: Analyze One Numeric Variable

# Get the mean Rate
mean(rates$Rate)

# Get the median Rate
median(rates$Rate)

# Get the minimum Rate
min(rates$Rate)

# Get the maximum Rate
max(rates$Rate)

# Get the quantiles
quantile(rates$Rate)

# Get the interquartile range
IQR(rates$Rate)

# Get the varience
var(rates$Rate)

# Get the standard deviation
sd(rates$Rate)

# Load the moments package
library(moments)

# Get the skewness of Rate
skewness(rates$Rate)

# Get the kertosis of Rate
kurtosis(rates$Rate)

# Summarize a numeric variable
summary(rates$Rate)

# Question: What do you imagine this distribution looks like?

### Problem 3: Analyze Two Categorical Variables

# Create a contingency table for Age Group and Gender
table(rates$Age.Group, rates$Gender)

# Question: Which age group and gender has the most mortality rate records?

### Problem 4: Analyze Two Numeric Variables

# Get the correlation coefficient of Age Group (Low) and Rate
cor(rates$Age.Group.Low, rates$Rate)

# Get the correlation coefficient of Population and Rate
cor(rates$Population, rates$Rate)

# Question: Which is a stronger correlation? Why?

### Problem 5: Analyze a Numeric Variable
### Grouped by a Categorical Variable

# Get average Rate by Gender
tapply(rates$Rate, rates$Gender, mean)

# Question: Who has the higher mortality rate?

### Problem 6: Analyze Many Variables

# Create a correlation matrix for the last five columns
cor(rates[, 8:12])

# Summarize an entire rates table
summary(rates)