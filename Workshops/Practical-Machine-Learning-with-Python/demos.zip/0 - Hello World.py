# Lab 0 - Hello World

#%% Assign a character string to a variable
x = "Hello World"

#%% Print the variable
print(x)

